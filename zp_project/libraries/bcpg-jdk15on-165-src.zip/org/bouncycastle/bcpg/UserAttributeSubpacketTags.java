package org.bouncycastle.bcpg;

/**
 * Basic PGP user attribute sub-packet tag types.
 */
public interface UserAttributeSubpacketTags 
{
    public static final int IMAGE_ATTRIBUTE = 1;
}
